import streamlit as st
import requests

st.set_page_config(page_title="Cultural RAG & Adjudicator", layout="wide")

st.title("Cultural RAG & Dual-Language Adjudicator")
st.markdown("Explore cultural QA with semantic agreement check & LLM adjudication.")

API_URL = "http://127.0.0.1:8000/process_cultural_qa"

with st.form("qa_form"):
    question = st.text_input("Question:", "What is the cultural significance of Chuseok?")
    country = st.selectbox("Country:", ["South Korea", "Ethiopia", "China", "Indonesia", "Azerbaijan"])
    language = st.selectbox("Local Language:", ["Korean", "Amharic", "Chinese", "Indonesian", "Azerbaijani"])
    submit = st.form_submit_button("Analyze & Evaluate")

if submit:
    with st.spinner("Processing dual-language generation and agreement check..."):
        try:
            payload = {"question": question, "country": country, "language": language}
            response = requests.post(API_URL, json=payload)
            if response.status_code == 200:
                data = response.json()
                
                col1, col2 = st.columns(2)
                with col1:
                    st.subheader("Local Language Response")
                    st.write(data.get("local_answer"))
                with col2:
                    st.subheader("English Response")
                    st.write(data.get("english_answer"))
                
                st.divider()
                st.metric("Semantic Similarity Score", f"{data.get('similarity_score', 0):.4f}")
                
                if data.get("is_disagreed"):
                    st.warning("Disagreement Detected! Adjudicator invoked with KB facts.")
                    st.subheader("Retrieved Ground-Truth Facts")
                    st.json(data.get("retrieved_facts"))
                else:
                    st.success("High Semantic Agreement! Direct response accepted.")
                    
                st.subheader("Final Answer")
                st.success(data.get("final_answer"))
            else:
                st.error(f"API Error ({response.status_code}): {response.text}")
        except Exception as e:
            st.error(f"Failed to connect to API server: {e}")