import os
import time
import google.generativeai as genai

genai.configure(api_key=os.getenv("GEMINI_API_KEY", ""))

MODEL_NAME = "gemini-3.8-flash"

def build_judge_prompt(question: str, local_ans: str, english_ans: str, facts: list) -> str:
    context_str = "\n".join([f"- {item.get('text', '')}" for item in facts]) if facts else "No specific ground facts found."
    
    prompt = f"""You are a cultural knowledge adjudicator.
Two distinct model responses were generated for a cultural question—one in the local language and one in English. They show semantic divergence.

Question: {question}

Local Answer (translated context):
{local_ans}

English Answer:
{english_ans}

Retrieved Ground-Truth Cultural Facts:
{context_str}

Evaluate both answers against the retrieved facts and cultural context. Provide a single, authoritative, accurate, and culturally nuanced answer in English.
"""
    return prompt

def run_judge(prompt: str) -> str:
    model = genai.GenerativeModel(MODEL_NAME)
    
    for attempt in range(3):
        try:
            response = model.generate_content(prompt)
            return response.text.strip()
        except Exception as e:
            err_msg = str(e)
            if "429" in err_msg or "Quota exceeded" in err_msg:
                time.sleep(15)
                continue
            return f"Error executing judge evaluation: {err_msg}"
            
    return "Error executing judge evaluation: Rate limit reached."