import numpy as np
from sentence_transformers import SentenceTransformer

model = None

def get_embedding_model():
    global model
    if model is None:
        model = SentenceTransformer("intfloat/multilingual-e5-base")
    return model

def check_disagreement(local_answer: str, english_answer: str, threshold: float = 0.75):
    """Calculates cosine similarity between local and English answers to detect disagreement."""
    embedder = get_embedding_model()
    
    embeddings = embedder.encode(
        [f"passage: {local_answer}", f"passage: {english_answer}"], 
        normalize_embeddings=True
    )
    
    similarity = float(np.dot(embeddings[0], embeddings[1]))
    is_disagreed = similarity < threshold
    
    return similarity, is_disagreed