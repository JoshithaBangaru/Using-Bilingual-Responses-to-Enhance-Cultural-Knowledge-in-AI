import os
import json
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

EMBEDDING_MODEL_NAME = "intfloat/multilingual-e5-large"
DATA_PATH = "cultural_data.json"
INDEX_PATH = "faiss_index.bin"
METADATA_PATH = "metadata.json"

model = None
index = None
metadata = []

def extract_text(item):
    """Safely extract text content from dictionary item regardless of key name."""
    if isinstance(item, str):
        return item
    if isinstance(item, dict):
        for key in ['text', 'fact', 'content', 'snippet', 'passage', 'summary']:
            if key in item and item[key]:
                return str(item[key])
        return " ".join([str(v) for v in item.values() if v])
    return str(item)

def load_retriever_resources():
    global model, index, metadata
    if model is None:
        model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    if os.path.exists(INDEX_PATH) and os.path.exists(METADATA_PATH):
        index = faiss.read_index(INDEX_PATH)
        with open(METADATA_PATH, "r", encoding="utf-8") as f:
            metadata = json.load(f)

def retrieve_cultural_evidence(query: str, country: str = None, top_k: int = 5):
    load_retriever_resources()
    if index is None or not metadata:
        return []
    
    query_embedding = model.encode([f"query: {query}"], normalize_embeddings=True)
    fetch_k = top_k * 5 if country else top_k
    distances, indices = index.search(np.array(query_embedding, dtype=np.float32), fetch_k)
    
    results = []
    for idx in indices[0]:
        if idx == -1 or idx >= len(metadata):
            continue
        item = metadata[idx]
        if country and item.get("country", "").lower() != country.lower():
            continue
        results.append(item)
        if len(results) >= top_k:
            break
            
    return results

def search_kb(query: str, country: str = None, top_k: int = 5):
    """Unified wrapper around vector database retrieval."""
    return retrieve_cultural_evidence(query=query, country=country, top_k=top_k)

if __name__ == "__main__":
    if os.path.exists(DATA_PATH):
        with open(DATA_PATH, "r", encoding="utf-8") as f:
            raw_data = json.load(f)
        
        model = SentenceTransformer(EMBEDDING_MODEL_NAME)
        documents = [f"passage: {extract_text(item)}" for item in raw_data]
        embeddings = model.encode(documents, normalize_embeddings=True, show_progress_bar=True)
        
        dimension = embeddings.shape[1]
        faiss_index = faiss.IndexFlatIP(dimension)
        faiss_index.add(np.array(embeddings, dtype=np.float32))
        
        faiss.write_index(faiss_index, INDEX_PATH)
        with open(METADATA_PATH, "w", encoding="utf-8") as f:
            json.dump(raw_data, f, ensure_ascii=False, indent=2)
        print("FAISS index and metadata successfully generated.")