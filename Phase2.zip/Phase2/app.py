import sqlite3
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from kb_retriever import search_kb
from dual_gen import generate_bilingual_answers
import disagreement
import judge

app = FastAPI(title="Dual-Language Cultural QA API")

DB_NAME = "experiments.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS evaluation_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT,
            country TEXT,
            language TEXT,
            local_answer TEXT,
            english_answer TEXT,
            similarity_score REAL,
            is_disagreed INTEGER,
            final_answer TEXT,
            retrieved_facts TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

init_db()

class QueryRequest(BaseModel):
    question: str
    country: Optional[str] = ""
    language: Optional[str] = "English"

class RetrieveRequest(BaseModel):
    query: str
    country: Optional[str] = None
    top_k: Optional[int] = 5

@app.post("/retrieve")
def retrieve_endpoint(request: RetrieveRequest):
    results = search_kb(query=request.query, country=request.country, top_k=request.top_k)
    return {"results": results}

@app.post("/process_cultural_qa")
@app.post("/api/evaluate")
def evaluate_endpoint(request: QueryRequest):
    try:
        bilingual_output = generate_bilingual_answers(
            question=request.question,
            country=request.country,
            language=request.language
        )
        
        local_ans = bilingual_output["local_answer"]
        english_ans = bilingual_output["english_answer"]

        similarity_score, is_disagreed = disagreement.check_disagreement(local_ans, english_ans)

        retrieved_facts = []
        if is_disagreed:
            retrieved_facts = search_kb(query=request.question, country=request.country)
            judge_prompt = judge.build_judge_prompt(
                question=request.question,
                local_ans=local_ans,
                english_ans=english_ans,
                facts=retrieved_facts
            )
            final_answer = judge.run_judge(judge_prompt)
        else:
            final_answer = english_ans

        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO evaluation_logs 
            (question, country, language, local_answer, english_answer, similarity_score, is_disagreed, final_answer, retrieved_facts)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            request.question,
            request.country,
            request.language,
            local_ans,
            english_ans,
            similarity_score,
            1 if is_disagreed else 0,
            final_answer,
            str(retrieved_facts)
        ))
        conn.commit()
        conn.close()

        return {
            "question": request.question,
            "country": request.country,
            "local_answer": local_ans,
            "english_answer": english_ans,
            "similarity_score": similarity_score,
            "is_disagreed": is_disagreed,
            "final_answer": final_answer,
            "retrieved_facts": retrieved_facts
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))