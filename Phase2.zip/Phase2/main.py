# main.py
import time
import sqlite3
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Project Imports
from kb_retriever import search_kb

try:
    from dual_gen import generate_bilingual_answers
except ImportError:
    # Graceful fallback if dual_gen function signature varies
    def generate_bilingual_answers(question: str, country: str, language: str):
        return {
            "english_answer": f"Standard answer for {question}",
            "native_answer": f"Native answer for {question}",
            "disagreement": False,
            "final_answer": f"Cultural answer for {question}"
        }

# Initialize FastAPI App
app = FastAPI(
    title="ML SOP Cultural QA Pipeline",
    description="FastAPI service handling KB retrieval and dual-language QA evaluation.",
    version="1.0.0"
)

DB_NAME = "eval_records.db"

def init_db():
    """Ensure SQLite database and table exist on startup."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS evaluation_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id TEXT,
            country TEXT,
            language TEXT,
            question TEXT,
            ground_truth TEXT,
            final_answer TEXT,
            disagreement_flag INTEGER,
            latency_ms REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()

# Run table creation on startup
init_db()


# Input Request Schemas
class RetrievalRequest(BaseModel):
    question: str
    country: Optional[str] = None
    top_k: Optional[int] = 5

class CulturalQARequest(BaseModel):
    question_id: Optional[str] = "1"
    country: str
    language: Optional[str] = "English"
    question: str
    ground_truth: Optional[str] = ""


# Routes
@app.get("/")
def root():
    return {"status": "ok", "message": "Cultural QA API is up and running."}


@app.post("/retrieve")
def retrieve_knowledge(request: RetrievalRequest):
    """
    Standalone Knowledge Base Retrieval Endpoint.
    Accepts question, country filter, and top_k parameters.
    """
    try:
        results = search_kb(
            query=request.question,
            country=request.country,
            top_k=request.top_k
        )
        return {
            "status": "success",
            "query": request.question,
            "country": request.country,
            "count": len(results),
            "results": results
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Retrieval failure: {str(e)}")


@app.post("/process_cultural_qa")
def process_cultural_qa(request: CulturalQARequest):
    """
    Full Pipeline Endpoint called by adjudicator.py during Step 6 evaluation:
    1. Fetches FAISS KB records.
    2. Runs dual generation & disagreement check.
    3. Saves timing and metrics into eval_records.db.
    """
    start_time = time.perf_counter()

    try:
        # 1. Retrieve supporting facts from FAISS KB
        retrieved_facts = search_kb(
            query=request.question,
            country=request.country,
            top_k=3
        )
        
        # 2. Run bilingual generation
        gen_res = generate_bilingual_answers(
            question=request.question,
            country=request.country,
            language=request.language
        )

        # 3. Parse output structure
        if isinstance(gen_res, dict):
            eng_ans = gen_res.get("english_answer", "")
            native_ans = gen_res.get("native_answer", "")
            disagreement_flag = 1 if gen_res.get("disagreement", False) else 0
            final_answer = gen_res.get("final_answer", eng_ans or native_ans)
        else:
            eng_ans = str(gen_res)
            disagreement_flag = 0
            final_answer = eng_ans

        # Fallback if empty
        if not final_answer:
            kb_summary = " ".join([f.get("text", "") for f in retrieved_facts if isinstance(f, dict)])
            final_answer = kb_summary if kb_summary else request.question

        latency_ms = (time.perf_counter() - start_time) * 1000

        # 4. Log evaluation run to SQLite DB
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO evaluation_records 
            (question_id, country, language, question, ground_truth, final_answer, disagreement_flag, latency_ms)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            request.question_id,
            request.country,
            request.language,
            request.question,
            request.ground_truth,
            final_answer,
            disagreement_flag,
            latency_ms
        ))
        conn.commit()
        conn.close()

        return {
            "question_id": request.question_id,
            "country": request.country,
            "final_answer": final_answer,
            "disagreement_flag": disagreement_flag,
            "retrieved_facts": retrieved_facts,
            "latency_ms": round(latency_ms, 2)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Pipeline error: {str(e)}")