# database.py
import sqlite3

DB_NAME = "eval_records.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS evaluation_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id TEXT,
            country TEXT,
            question_english TEXT,
            answer_local TEXT,
            answer_english TEXT,
            semantic_similarity REAL,
            disagreement_flag INTEGER,
            retrieved_kb_evidence TEXT,
            final_answer TEXT,
            ground_truth TEXT,
            is_correct INTEGER,
            latency_ms REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

def log_evaluation_record(data: dict):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO evaluation_records (
            question_id, country, question_english, answer_local, answer_english,
            semantic_similarity, disagreement_flag, retrieved_kb_evidence,
            final_answer, ground_truth, is_correct, latency_ms
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        data.get("question_id"), data.get("country"), data.get("question_english"),
        data.get("answer_local"), data.get("answer_english"), data.get("semantic_similarity"),
        data.get("disagreement_flag"), data.get("retrieved_kb_evidence"),
        data.get("final_answer"), data.get("ground_truth"), data.get("is_correct"),
        data.get("latency_ms")
    ))
    conn.commit()
    conn.close()

if __name__ == "__main__":
    init_db()
    print("SQLite Database initialized successfully.")