import os
import json
import time
import google.generativeai as genai

genai.configure(api_key=os.getenv("GEMINI_API_KEY", ""))

MODEL_NAME = "gemini-3.8-flash"

COUNTRY_LANGUAGE_MAP = {
    "South Korea": "Korean",
    "Ethiopia": "Amharic",
    "China": "Chinese",
    "Indonesia": "Indonesian",
    "Azerbaijan": "Azerbaijani"
}

def get_country_language(country: str) -> str:
    return COUNTRY_LANGUAGE_MAP.get(country, "English")

def generate_bilingual_answers(question: str, country: str = "", language: str = "English") -> dict:
    """Generates both answer candidates in a single API call using gemini-3.8-flash."""
    local_lang = language if (language and language != "English") else get_country_language(country)
    model = genai.GenerativeModel(MODEL_NAME)
    
    prompt = f"""Answer the following cultural question in two languages:
1. In {local_lang}
2. In English

Return ONLY a JSON object with keys "local_answer" and "english_answer".

Question: {question}"""

    for attempt in range(3):
        try:
            response = model.generate_content(
                prompt,
                generation_config={"response_mime_type": "application/json"}
            )
            data = json.loads(response.text.strip())
            return {
                "local_answer": data.get("local_answer", ""),
                "english_answer": data.get("english_answer", ""),
                "local_language": local_lang
            }
        except Exception as e:
            err_msg = str(e)
            if "429" in err_msg or "Quota exceeded" in err_msg:
                time.sleep(15)  # Wait for free tier limit window to reset
                continue
            return {
                "local_answer": f"Error: {err_msg}",
                "english_answer": f"Error: {err_msg}",
                "local_language": local_lang
            }

    return {
        "local_answer": "Error: Rate limit reached. Please wait 20 seconds.",
        "english_answer": "Error: Rate limit reached. Please wait 20 seconds.",
        "local_language": local_lang
    }