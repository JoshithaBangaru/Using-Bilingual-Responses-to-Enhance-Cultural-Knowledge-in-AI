import json
import wikipediaapi

# Initialize Wikipedia API with a standard User-Agent header
wiki = wikipediaapi.Wikipedia(
    user_agent="CulturalKBPipeline/1.0 (contact@example.com)",
    language="en"
)

# Target countries and the primary categories/topics to extract
TARGET_COUNTRIES = {
    "South Korea": {"language": "Korean", "topics": ["Culture of Korea", "Korean cuisine", "Korean festivals"]},
    "Ethiopia": {"language": "Amharic", "topics": ["Culture of Ethiopia", "Ethiopian cuisine", "Festivals in Ethiopia"]},
    "China": {"language": "Chinese", "topics": ["Culture of China", "Chinese cuisine", "Public holidays in China"]},
    "Indonesia": {"language": "Indonesian", "topics": ["Culture of Indonesia", "Indonesian cuisine", "List of festivals in Indonesia"]},
    "Azerbaijan": {"language": "Azerbaijani", "topics": ["Culture of Azerbaijan", "Azerbaijani cuisine", "Public holidays in Azerbaijan"]}
}

def extract_facts_from_page(page, country, language):
    extracted_facts = []
    
    # Process sections under each page
    for section in page.sections:
        # Filter out irrelevant administrative sections
        if section.title.lower() in ["see also", "references", "external links", "further reading", "notes"]:
            continue
            
        # Split section text into individual sentences/paragraphs
        paragraphs = [p.strip() for p in section.text.split("\n") if len(p.strip()) > 50]
        
        for paragraph in paragraphs:
            # First sentence used as a quick summary
            sentences = paragraph.split(". ")
            if not sentences:
                continue
                
            fact_text = paragraph[:500]  # Chunk limit to prevent oversized vectors
            
            extracted_facts.append({
                "country": country,
                "language": language,
                "category": section.title,
                "topic": page.title,
                "fact": fact_text,
                "source": page.fullurl
            })
            
    return extracted_facts

def main():
    all_facts = []
    
    for country, meta in TARGET_COUNTRIES.items():
        print(f"Fetching data for {country}...")
        for topic in meta["topics"]:
            page = wiki.page(topic)
            if page.exists():
                facts = extract_facts_from_page(page, country, meta["language"])
                all_facts.extend(facts)
                print(f"  - Scraped {len(facts)} facts from '{topic}'")
            else:
                print(f"  - Page '{topic}' not found.")
                
    # Save the consolidated dataset
    out_file = "cultural_data.json"
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(all_facts, f, ensure_ascii=False, indent=2)
        
    print(f"\nSuccessfully saved {len(all_facts)} total facts to '{out_file}'.")

if __name__ == "__main__":
    main()