# adjudicator.py
import requests
import time
import numpy as np
import pandas as pd
from datasets import load_dataset
from tqdm import tqdm
import sqlite3

# API Configuration
API_URL = "http://127.0.0.1:8000/process_cultural_qa"
DB_NAME = "eval_records.db"

# Target countries matching your database and KB setup
TARGET_COUNTRIES = ["Japan", "Brazil", "France", "Egypt", "South Korea", "India", "Ethiopia", "Mexico"]

def load_blend_evaluation_samples(samples_per_country: int = 10):
    """
    Loads sample questions from the BLEnD benchmark on HuggingFace.
    Fallback to synthetic benchmark if dataset structure varies.
    """
    print("Loading BLEnD Benchmark Dataset...")
    samples = []
    try:
        # Load dataset from Hugging Face repository
        ds = load_dataset("nayeon212/BLEnD", split="test", streaming=True)
        
        country_counts = {c: 0 for c in TARGET_COUNTRIES}
        for item in ds:
            country = item.get("country")
            if country in TARGET_COUNTRIES and country_counts[country] < samples_per_country:
                samples.append({
                    "question_id": str(item.get("id", len(samples))),
                    "country": country,
                    "language": item.get("language", "English"),
                    "question": item.get("question_en", item.get("question")),
                    "ground_truth": item.get("answer")
                })
                country_counts[country] += 1
                if all(count >= samples_per_country for count in country_counts.values()):
                    break
        print(f"Successfully loaded {len(samples)} samples across {len(TARGET_COUNTRIES)} countries.")
    except Exception as e:
        print(f"HuggingFace dataset stream failed or unavailable: {e}")
        print("Falling back to local evaluation test set...")
        samples = get_local_fallback_benchmark()
    
    return samples

def get_local_fallback_benchmark():
    """Fallback evaluation set matching BLEnD schema."""
    return [
        {"question_id": "1", "country": "Japan", "language": "Japanese", "question": "What is the traditional Japanese tea ceremony called?", "ground_truth": "Chanoyu"},
        {"question_id": "2", "country": "Brazil", "language": "Portuguese", "question": "What is the traditional Brazilian carnival dance and music style?", "ground_truth": "Samba"},
        {"question_id": "3", "country": "India", "language": "Hindi", "question": "What is the traditional spice blend used in North Indian cooking?", "ground_truth": "Garam Masala"},
        {"question_id": "4", "country": "Ethiopia", "language": "Amharic", "question": "What flatbread is used to scoop up food in traditional Ethiopian dining?", "ground_truth": "Injera"},
        {"question_id": "5", "country": "Mexico", "language": "Spanish", "question": "What holiday honors deceased loved ones with altars and marigolds?", "ground_truth": "Day of the Dead"},
        {"question_id": "6", "country": "France", "language": "French", "question": "What traditional French long thin loaf of bread is iconic to its culture?", "ground_truth": "Baguette"},
        {"question_id": "7", "country": "Egypt", "language": "Arabic", "question": "What major spring festival has been celebrated in Egypt since ancient times?", "ground_truth": "Sham el-Nessim"},
        {"question_id": "8", "country": "South Korea", "language": "Korean", "question": "What is the traditional Korean clothing worn during holiday celebrations?", "ground_truth": "Hanbok"}
    ]

def evaluate_system():
    samples = load_blend_evaluation_samples(samples_per_country=5)
    
    total_samples = len(samples)
    correct_count = 0
    disagreement_count = 0
    judge_correct_count = 0
    latencies = []

    print("\n================ STARTING PIPELINE EVALUATION ================\n")

    for sample in tqdm(samples, desc="Evaluating Queries"):
        payload = {
            "question_id": sample["question_id"],
            "country": sample["country"],
            "language": sample["language"],
            "question": sample["question"],
            "ground_truth": sample["ground_truth"]
        }

        try:
            start_time = time.perf_counter()
            response = requests.post(API_URL, json=payload)
            latency = (time.perf_counter() - start_time) * 1000
            latencies.append(latency)

            if response.status_code == 200:
                res_data = response.json()
                final_ans = res_data["final_answer"]
                gt = sample["ground_truth"].lower()
                
                # Check correctness
                is_correct = gt in final_ans.lower()
                if is_correct:
                    correct_count += 1

                # Track disagreement metrics
                if res_data.get("disagreement_flag") == 1:
                    disagreement_count += 1
                    if is_correct:
                        judge_correct_count += 1

            else:
                print(f"API Error {response.status_code} for question ID {sample['question_id']}")

        except Exception as e:
            print(f"Request failed: {e}")

    # Compute Final Academic Metrics
    accuracy = (correct_count / total_samples) * 100 if total_samples > 0 else 0
    adjudication_success_rate = (judge_correct_count / disagreement_count * 100) if disagreement_count > 0 else 0
    avg_latency = np.mean(latencies) if latencies else 0

    print("\n================ FINAL EVALUATION RESULTS ================")
    print(f"Total Benchmark Queries Executed   : {total_samples}")
    print(f"Overall System Accuracy            : {accuracy:.2f}%")
    print(f"Disagreement Trigger Rate          : {(disagreement_count/total_samples)*100:.2f}%")
    print(f"LLM-as-a-Judge Success Rate        : {adjudication_success_rate:.2f}%")
    print(f"Average Pipeline Latency           : {avg_latency:.2f} ms")
    print("==========================================================\n")

if __name__ == "__main__":
    evaluate_system()